package Testing;

import static org.testng.Assert.assertTrue;

import com.extinct.tankstars.TankStars;

import org.junit.Test;

public class ExitScreenTest {
    @Test
    public static void main(String args[]){
        TankStars game = new TankStars();
        assertTrue(true);
    }

}
