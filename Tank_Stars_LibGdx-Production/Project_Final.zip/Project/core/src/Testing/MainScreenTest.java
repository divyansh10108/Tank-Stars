package Testing;

import static org.testng.Assert.assertTrue;

import com.extinct.tankstars.TankStars;

import org.junit.Test;

public class MainScreenTest {
    @Test
    public static void main(String args[]){
        TankStars game = new TankStars();
//        Screen sc = new ExitScreen(game);
        assertTrue(true);
    }

}
